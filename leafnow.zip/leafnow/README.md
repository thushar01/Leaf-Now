# E-mandi
Web application for Vegetable Marketing System



# to-do list

# profile.php-->
~~1. add role div to profile page with dropdown box.~~
~~4.add city with dropdown from govt table~~
	
~~2. add change password func~~

~~3.remove state and country~~
	
		
# vegetable table-->

~~1.rename vegtables in upper camelcase~~

# sell.php-->
	
~~2.if(same username and dealer and vegetable ) update quantity of vegtable~~
	~~3.if role is civilian redirect to profile page to change role.~~
~~1.extract regions from govt table~~

# singlePro.php-->(MAJOR)
~~2.if(same username and dealer and vegetable update quantity )~~
~~1.errors in php(duplicate entries in database)~~
~~3. Edit Dropdowns  in page for Retailer~~
~~4. Show govt price~~
~~5. add js ajax to show diff in prices~~
~~6. region dropdown box.~~
~~7. separate retailer and wholeseller acc to roles (using join)  for pricing diff dropdowns***~~
~~8.while buying show different for retailer and civilian//put if~~
	
	

# cart.php-->
~~2.if checkout go to payment page~~
~~1.backend (retrieve from cart table and display(front end))~~
	
	

# payment.php-->

~~1.~~




# header-->

~~1.search functionality ~~




##  OVERALL--->

~~1.Put Pages for Govt~~
~~2.Add Admin Page~~.
~~3.revenue.~~
~~4.payment.php to be created~~
~~5.set linking for all pages.~~


